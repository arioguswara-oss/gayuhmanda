<?php
/**
 * Plugin Name: Gayuh Mandala Landing for Elementor
 * Description: Menampilkan landing page bilingual PT Gayuh Mandala Teknika melalui shortcode khusus di Elementor, tanpa mengganti tema atau beranda.
 * Version: 1.1.1
 * Requires PHP: 7.4
 * Requires at least: 5.8
 * Author: PT Gayuh Mandala Teknika
 * Text Domain: gayuh-landing
 */
if (!defined('ABSPATH')) { exit; }

function gayuh_landing_shortcode() {
    $src = plugins_url('site/index.html', __FILE__);
    // The embedded layout is isolated from global Elementor/theme styles.
    $id = 'gayuh-landing-' . wp_rand(100000,999999);
    $html = '<div class="gayuh-landing-container" style="width:100%;max-width:100%;margin:0;overflow:hidden">';
    $html .= '<iframe class="gayuh-landing-frame" id="' . esc_attr($id) . '" src="' . esc_url($src) . '" title="PT Gayuh Mandala Teknika – bilingual landing page" loading="eager" scrolling="no" style="display:block;width:100%;height:1100px;min-height:650px;border:0;background:#fff" referrerpolicy="strict-origin-when-cross-origin"></iframe>';
    $html .= '</div>';
    return $html;
}
add_shortcode('gayuh_landing', 'gayuh_landing_shortcode');

function gayuh_landing_embed_script() {
    // No global layout changes; only frames emitted by this shortcode are targeted.
    ?>
    <script id="gayuh-landing-resizer">
    (function () {
      function resizeFrame(frame, height) {
        var n = Number(height);
        if (!Number.isFinite(n) || n < 400 || n > 60000) return;
        frame.style.height = Math.ceil(n + 2) + 'px';
      }
      window.addEventListener('message', function(event) {
        if (event.origin !== window.location.origin || !event.data || event.data.type !== 'gayuh-landing-height-v1') return;
        var frames = document.querySelectorAll('iframe.gayuh-landing-frame');
        for (var i = 0; i < frames.length; i++) {
          if (frames[i].contentWindow === event.source) {
            resizeFrame(frames[i], event.data.height);
            break;
          }
        }
      });
      function inspect(frame) {
        try {
          if (!frame.contentDocument) return;
          var doc = frame.contentDocument;
          var update = function() {
            if (doc.body && doc.documentElement) resizeFrame(frame, Math.max(doc.body.scrollHeight, doc.documentElement.scrollHeight));
          };
          update();
          if (window.ResizeObserver && doc.body) new ResizeObserver(update).observe(doc.body);
          frame.addEventListener('load', update);
        } catch(e) { /* cross-origin or blocked: default iframe height is retained */ }
      }
      function initialize() {
        document.querySelectorAll('iframe.gayuh-landing-frame').forEach(function(frame) {
          frame.addEventListener('load', function() {inspect(frame)});
          if (frame.contentDocument && frame.contentDocument.readyState === 'complete') inspect(frame);
        });
      }
      if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initialize);
      else initialize();
    })();
    </script>
    <?php
}
// Footer hook only executes on front-end. Listener has no effect on pages without the shortcode.
add_action('wp_footer', 'gayuh_landing_embed_script', 50);
