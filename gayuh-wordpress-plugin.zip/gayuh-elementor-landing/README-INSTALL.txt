PT GAYUH MANDALA TEKNIKA — LANDING PAGE ELEMENTOR (STAGING / SAFE INSTALL)

Isi ZIP: plugin WordPress, landing page bilingual, 21 logo mitra.
Tidak mengganti tema, tidak mengubah halaman beranda, tidak mengubah database bisnis, dan tidak mengirim formulir secara otomatis.

CARA PASANG TANPA MENGGANGGU WEBSITE LAMA:
1. Backup WordPress (files + database). Lebih aman uji dahulu di staging jika tersedia.
2. Dashboard WordPress > Plugins > Add New Plugin > Upload Plugin.
3. Pilih ZIP ini, Install Now, Activate.
4. Pages > Add New, judul misalnya "Landing Preview". JANGAN mengganti Settings > Reading atau homepage.
5. Klik Edit with Elementor. Pada Page Settings > Page Layout, pilih Elementor Canvas untuk halaman preview penuh (opsional; hanya halaman ini). Jika ingin mempertahankan header/footer tema, pilih Elementor Full Width.
6. Tambahkan widget Shortcode dengan isi: [gayuh_landing]
7. Atur section/container Elementor ke Full Width, padding 0, gap 0 bila ingin halaman mengisi lebar layar.
8. Save Draft / Preview lebih dulu. Pastikan navigasi, tombol bahasa ID/EN, logo, formulir, dan responsif berfungsi. Publish halaman percobaan hanya sesudah setuju.
9. Tidak ada perubahan beranda secara otomatis. Untuk menjadikannya homepage diperlukan langkah terpisah dengan persetujuan pemilik situs.

PENTING:
- Desain disisipkan lewat iframe same-origin supaya CSS situs lama dan Elementor tidak saling menimpa. Konten di dalam iframe tidak dapat diedit per elemen lewat editor Elementor; edit berkas site/index.html dalam plugin untuk mengubah detail konten/desain.
- SEO: konten iframe dapat berbeda dari konten halaman induk untuk mesin pencari. Untuk SEO bilingual penuh dengan URL /id/ dan /en/, hreflang, dan integrasi multilingual native WordPress, implementasi lanjutan diperlukan.
- Otomatis bahasa berdasarkan negara IP pengunjung lewat ipwho.is. Jika diblokir atau gagal, pakai bahasa browser; pilihan manual bendera tersimpan lokal. VPN bisa mengubah hasil. Ini melibatkan layanan geolokasi pihak ketiga.
- Kontak formulir membuka aplikasi email pengunjung (mailto), bukan mengirim otomatis atau menyimpan lead ke database.
- Logo mitra menggunakan aset yang diberikan pemilik website. Brand Shanghai Manwang Electromechanical Equipment Co., Ltd sudah diberi nama sesuai konfirmasi pemilik; logo GM untuk panel Tentang Kami disertakan di plugin.
- Logo perusahaan menggunakan URL yang ada pada desain asal. Foto hero mengambil gambar Unsplash; akses internet diperlukan untuk menampilkan aset eksternal.
- Plugin tidak terhubung ke WordPress Anda: instalasi dan pengujian di hosting belum dilakukan.
- Untuk rollback: hapus halaman preview atau nonaktifkan plugin. Tidak perlu mengubah file tema.

PEMBARUAN V1.1.0:
- Perbaiki nama dan gambar logo Shanghai Manwang.
- Hapus catatan/disclaimer logo di bagian Brand Mitra.
- Ganti huruf G pada panel Tentang Kami dengan logo GM pemilik, beri warna tepi lembut senada navy-teal.
- Jika plugin versi sebelumnya telah terpasang, backup terlebih dahulu dan pilih Replace current with uploaded saat WordPress menampilkan opsi penggantian. Shortcode [gayuh_landing] tidak berubah.

Versi paket 1.1.1: struktur arsip ZIP dibuat ulang untuk installer plugin WordPress. Gunakan file PLUGIN_WORDPRESS_GAYUH_MANDALA_ELEMENTOR_V1_1_1.zip, BUKAN arsip Bilingual_Website.
