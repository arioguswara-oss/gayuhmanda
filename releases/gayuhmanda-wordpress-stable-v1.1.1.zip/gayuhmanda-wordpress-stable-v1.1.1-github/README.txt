PT GAYUH MANDALA TEKNIKA — WORDPRESS STABLE BUNDLE V1.1.1
Release date: 2026-09-28

COMPONENTS
1. Gayuh Site Core v1.0.2
2. Gayuh Fullwidth Templates v1.0.0
3. Gayuh Mandala GeneratePress Child Theme v1.1.1

INSTALL ORDER
1. Install GeneratePress parent theme.
2. Upload + activate gayuh-site-core-v1.0.2.zip.
3. Upload + activate gayuh-fullwidth-templates-v1.0.0.zip.
4. Upload gayuh-mandala-gp-child-v1.1.1.zip under Appearance > Themes and activate.
5. Blog/Artikel page: select template "Gayuh Blog / Insights".
6. Landing page: select "Gayuh Landing" or use shortcode [gayuh_landing].

CURRENT WORKING FEATURES
- Corporate industrial Gayuh design.
- Bilingual Indonesian/English UI with flag switcher.
- Dynamic partner brands.
- Dynamic WordPress blog/article layout.
- Full-width blog without default WordPress sidebar.
- Responsive GeneratePress logo sizing fix.
- Partner name corrected to Shanghai Manwang Electromechanical Equipment Co., Ltd.

The old "Gayuh Mandala Landing for Elementor" plugin is not required by this bundle.
