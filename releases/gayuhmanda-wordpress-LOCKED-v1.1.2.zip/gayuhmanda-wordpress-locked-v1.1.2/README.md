# Gayuh Mandala WordPress — LOCKED Baseline V1.1.2

Status: LOCKED / user-verified
Date: 28 Sep 2026

Components:
- Gayuh Site Core V1.0.2
- Gayuh Fullwidth Templates V1.0.0
- Gayuh Mandala GeneratePress Child Theme V1.1.2

Locked scope:
- Corporate industrial visual direction
- Bilingual ID/EN UI and flag switcher
- Dynamic Partner Brands
- Dynamic Blog/Artikel styling
- Full-width Blog / Insights template
- Desktop logo sizing fix
- Mobile header fix: compact GM logo + company name + tagline + clearer hamburger button
- Partner name: Shanghai Manwang Electromechanical Equipment Co., Ltd.

Do not change this package when developing the next version. Use it as rollback baseline.
