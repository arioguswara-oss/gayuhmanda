# Changelog

## V1.1.2 LOCKED — 28 Sep 2026
- User verified mobile header/logo result as good.
- Restored company identity text beside GM logo on mobile.
- Kept compact responsive logo proportions.
- Improved mobile hamburger visibility.
- Carries forward V1.1.1 Blog / Insights and desktop logo fixes.

## V1.1.1
- Fixed oversized GeneratePress logo.
- Added full-width Gayuh Blog / Insights page template.
- Removed default WordPress sidebar from Gayuh blog layout.

## Site Core V1.0.2
- Stable prefixed plugin implementation after fatal-error fixes.
